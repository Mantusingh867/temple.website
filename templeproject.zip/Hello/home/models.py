from django.db import models

# Create your models here.
# makemigrations - create changes and store in the file
# migrate - apply the pading changes created by makemigrations

class Contact(models.Model):
    name = models.CharField(max_length=122)
    email = models.CharField(max_length=122)
    phone = models.CharField(max_length=12)
    desc = models.TextField()
    date = models.DateField()

    def __str__(self):
        return self.name

    # ye banane ke baad terminal me ja kar (python manage.py makemigration)
    # yeha ke baad admin me jakar model import karna hai uske badh aaps.py me jakar (HomeConfig) ye copy karke setting me jakar install karna hai

